 <div class="chat-form">
                    
                        <div class="chat-container">
                            <div class="form-input">
                            <textarea class="textarea-control" placeholder="Please type your message here"></textarea>
                            </div><!--  closes form-input-->

                            <div class="form-input">
                            <label for="upload-files" id="upload-label"><i class="fas fa-paperclip fa-uploads"></i><i class="fas fa-file-image fa-uploads"></i></label>
                            <input type="file" id="upload-files" class="files-upload">
                            </div><!--  closes form-input-->

                        </div><!--  closes chat-container-->
                    </div><!--  closes chat form-->