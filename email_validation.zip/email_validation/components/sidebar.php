<section id="sidebar">

<ul class="left-ul">
<li><a href="#"><span class="profile-img-span"><img src="assets/img/prof4.jpg" alt="Profile Image" class="profile-img"></span></a></li>
<li><a href="index.php">Optimum Linkup <span class="cool-hover"></span></a></li>
<li><a href="change_name.php">Change Name <span class="cool-hover"></span></a></li>
<li><a href="change_password.php">Change Password <span class="cool-hover"></span></a></li>
<li><a href="#">110 user Online <span class="cool-hover"></span></a></li>
<li><a href="logout.php">Logout <span class="cool-hover"></span></a></li>
</ul>
</section><!--  closes sidebar-->