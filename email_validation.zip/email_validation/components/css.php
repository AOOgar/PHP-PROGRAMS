<?php include ("functions/init.php");?>
 <!-- CORE CSS-->    
    <link href="assets/css/style.css" type="text/css" rel="stylesheet">
    <link href="assets/fontawesome/css/all.css" type="text/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,900" rel="stylesheet" type="text/css" />