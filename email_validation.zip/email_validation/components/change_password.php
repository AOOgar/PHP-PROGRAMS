<div class="form-section">
                    <div class="form-grid">

                        <form method="POST" action="">

                             <div class="group">
                   <h2 class="form-heading">Change password</h2>
                </div><!--  close group div-->

                <div class="group">
                     <input type="password" name="current_password" class="control" placeholder="Your current password here....">
                </div><!--  close group div-->


                <div class="group">
                     <input type="password" name="new_password" class="control" placeholder="Your new password here....">
                </div><!--  close group div-->

                  <div class="group">
                     <input type="password" name="retype_new_password" class="control" placeholder="Your retype new password here....">
                </div><!--  close group div-->
               
            <div class="group">
                <input type="submit" name="change_password" class="btn account-btn" value="Save changes">
            </div><!--  close group div-->

            
            </form>

                    </div><!--  closes form grid-->
                </div><!--  closes form-section-->