<div class="form-area">
            <form id="register-form"  method="post" role="form" >

                <div class="group">
                   <h2 class="form-heading">Enter code </h2>
                </div><!--  close group div-->
				
				
          
                <div class="group">
                    <input type="text" name="code" id="code" class="control" placeholder="##########">
                </div><!--  close group div-->

            <div class="group">
                <input type="submit" name="code-submit" id="recover-submit" class="btn account-btn" value="Continue">
            </div><!--  close group div-->
			
               <a href="#" id="code-cancel" class="reset">Cancel</a>
            
            <input type="hidden" class="hide" name="token" id="token" value="">
            </form><!--  close form -->

        </div> <!--  close form-area div-->