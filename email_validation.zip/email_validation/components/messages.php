<div class="messages">
                        <div class="left-message common-margin">
                                <div class="sender-img-block">
                                    <img src="assets/img/prof4.jpg" class="sender-img">
                                     <span class="online-icon"></span>
                                </div><!--  closes sender-img-block-->
                                    <div class="left-msg-area">
                                        <div class="user-name-date">
                                            <span class="sender-name">
                                                OPtimum Linkup
                                            </span><!--  closes sender-name-->
                                            <span class="date-time">
                                                1 day ago
                                            </span><!--  closes date-time-->
                                        </div><!--  closes user-name-date-->
                                        <div class="left-msg">
                                            <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                        </div><!--  closes left-msg-->
                                    </div><!--  closes left-msg-area-->
                        </div><!--  closes left-message-->



                        <div class="left-message common-margin">
                                <div class="sender-img-block">
                                    <img src="assets/img/prof4.jpg" class="sender-img">
                                     <span class="offline-icon"></span>
                                </div><!--  closes sender-img-block-->
                                    <div class="left-msg-area">
                                        <div class="user-name-date">
                                            <span class="sender-name">
                                                OPtimum Linkup
                                            </span><!--  closes sender-name-->
                                            <span class="date-time">
                                                1 day ago
                                            </span><!--  closes date-time-->
                                        </div><!--  closes user-name-date-->
                                        <div class="left-msg">
                                            <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                        </div><!--  closes left-msg-->
                                    </div><!--  closes left-msg-area-->
                        </div><!--  closes left-message-->



                         <div class="right-messages common-margin">
                            <div class="right-msg-area">
                                 <span class="date-time right-time">
                                                1 day ago
                                </span><!--  closes date-time-->
                                    <div class="right-msg">
                                        <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                    </div><!--  closes right-msg-->
                            </div><!--  closes right msg-area-->
                        </div><!--  closes right messages-->



                        <div class="right-messages common-margin">
                            <div class="right-msg-area">
                                 <span class="date-time right-time">
                                                1 day ago
                                </span><!--  closes date-time-->
                                    <div class="right-msg">
                                        <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                    </div><!--  closes right-msg-->
                            </div><!--  closes right msg-area-->
                        </div><!--  closes right messages-->





                         <div class="right-messages common-margin">
                            <div class="right-msg-area">
                                 <span class="date-time right-time">
                                                1 day ago
                                </span><!--  closes date-time-->
                                    <div class="right-msg">
                                        <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                    </div><!--  closes right-msg-->
                            </div><!--  closes right msg-area-->
                        </div><!--  closes right messages-->



                         <div class="right-messages common-margin">
                            <div class="right-msg-area">
                                 <span class="date-time right-time">
                                                1 day ago
                                </span><!--  closes date-time-->
                                    <div class="right-msg">
                                        <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                    </div><!--  closes right-msg-->
                            </div><!--  closes right msg-area-->
                        </div><!--  closes right messages-->







                    <div class="left-message common-margin">
                                <div class="sender-img-block">
                                    <img src="assets/img/prof4.jpg" class="sender-img">
                                </div><!--  closes sender-img-block-->
                                    <div class="left-msg-area">
                                        <div class="user-name-date">
                                            <span class="sender-name">
                                                OPtimum Linkup
                                            </span><!--  closes sender-name-->
                                            <span class="date-time">
                                                1 day ago
                                            </span><!--  closes date-time-->
                                        </div><!--  closes user-name-date-->
                                        <div class="left-msg">
                                            <p>This is the information by Prof of the Linkup computers. Thanks and we really appreciate this</p>
                                        </div><!--  closes left-msg-->
                                    </div><!--  closes left-msg-area-->
                        </div><!--  closes left-message-->


                    </div><!--  closes messages-->