<script type="text/javascript"src="assets/js/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){

    $(".custom-bars").click(function(){
        $("#sidebar").slideToggle();
    })
})
</script>