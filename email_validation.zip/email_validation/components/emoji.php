<div class="emoji">
                        <img src="assets/emoji/emoji1.png" class="emoji-same">
                        <img src="assets/emoji/emoji2.png" class="emoji-same">
                        <img src="assets/emoji/emoji3.png" class="emoji-same">
                        <img src="assets/emoji/emoji4.png" class="emoji-same">
                        <img src="assets/emoji/emoji5.png" class="emoji-same">
                        <img src="assets/emoji/emoji6.png" class="emoji-same">
                        <img src="assets/emoji/emoji7.png" class="emoji-same">
                        <img src="assets/emoji/emoji8.png" class="emoji-same">
                        <img src="assets/emoji/emoji9.png" class="emoji-same">
                        <img src="assets/emoji/emoji10.png" class="emoji-same">
                        <img src="assets/emoji/emoji11.png" class="emoji-same">
                        <img src="assets/emoji/emoji12.png" class="emoji-same">
                        <img src="assets/emoji/emoji13.png" class="emoji-same">
                        <img src="assets/emoji/emoji14.png" class="emoji-same">
                        <img src="assets/emoji/emoji15.png" class="emoji-same">
                        <img src="assets/emoji/emoji16.png" class="emoji-same">
                        <img src="assets/emoji/emoji17.png" class="emoji-same">
                        <img src="assets/emoji/emoji18.png" class="emoji-same">
                        <img src="assets/emoji/emoji19.png" class="emoji-same">
                        <img src="assets/emoji/emoji20.png" class="emoji-same">

                    </div><!--  closes emoji-->