 <nav id="nav">
    <span class="bars">
        <i class="fas fa-bars custom-bars"></i>
    </span><!--  closes bar-->
    </nav><!--  closes nav-->