<div class="form-area">
            <form method="POST" action="">

                <div class="group">
                   <h2 class="form-heading">User Login</h2>
                </div><!--  close group div-->

          
                <div class="group">
                    <input type="email" name="email" class="control" placeholder="Your email here....">
                </div><!--  close group div-->


                <div class="group">
                     <input type="password" name="password" class="control" placeholder="Your password here....">
                </div><!--  close group div-->

                <div class="group">
                <input type="checkbox" name="remember" id="remember" class="link"> Remember Me
                </div><!--  close group div-->

            <div class="group">
                <input type="submit" name="login" class="btn account-btn" value="User Login">
            </div><!--  close group div-->
			
            <a href="signup.php" class="prof">New account registration</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="resetPassword.php" class="reset">Reset password</a>
            
            </form><!--  close form -->

        </div> <!--  close form-area div-->