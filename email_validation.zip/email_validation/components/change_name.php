<div class="form-section">
                    <div class="form-grid">

                        <form method="POST" action="">

                             <div class="group">
                   <h2 class="form-heading">Change Name</h2>
                </div><!--  close group div-->

                <div class="group">
                     <input type="text" name="user_name" class="control" placeholder="Your Name....">
                </div><!--  close group div-->

            <div class="group">
                <input type="submit" name="change_name" class="btn account-btn" value="Save changes">
            </div><!--  close group div-->

            
            </form>

                    </div><!--  closes form grid-->
                </div><!--  closes form-section-->