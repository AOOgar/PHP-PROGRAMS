<?php include ("functions/init.php");?>
<?php  activate_user(); ?>