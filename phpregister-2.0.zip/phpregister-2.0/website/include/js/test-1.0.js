function test() {
    alert("Function test called from test-xx.js file!");
}
